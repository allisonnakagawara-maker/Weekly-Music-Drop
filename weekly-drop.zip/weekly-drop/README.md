# Weekly Drop: setup (about 10 minutes)

1. Create a free GitHub account, then a new **public** repo (e.g. `weekly-drop`) and upload everything in this folder
   (including the hidden `.github` folder).
2. **Anthropic API key:** make one at console.anthropic.com, then in the repo go to
   Settings > Secrets and variables > Actions > New repository secret. Name: `ANTHROPIC_API_KEY`.
   (Each weekly run costs roughly a few cents of API usage.)
3. **Turn on hosting:** Settings > Pages > Source: "Deploy from a branch", branch `main`, folder `/ (root)`.
   Your site will be at `https://YOUR-USERNAME.github.io/weekly-drop/`. Favorite that in Chrome.
4. **Test it:** Actions tab > "Weekly drop" > Run workflow. In a minute or two `drops.json` gets a new week.
   After that it runs by itself every Monday.

Edit `taste.json` any time to change your loves/avoids or add artists to `blocklist`.
Heard / Loved / Skip marks are saved per browser (not synced between devices).
