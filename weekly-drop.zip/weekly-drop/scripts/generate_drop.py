"""Weekly Drop generator. Stdlib only. Needs env var ANTHROPIC_API_KEY."""
import json, os, re, sys, datetime, urllib.request, urllib.error

MODEL = os.environ.get("DROP_MODEL", "claude-sonnet-5-5")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
taste = json.load(open(os.path.join(ROOT, "taste.json")))
path = os.path.join(ROOT, "drops.json")
drops = json.load(open(path)) if os.path.exists(path) else []

seen_songs = {(s["a"].lower(), s["t"].lower()) for d in drops for s in d["songs"]}
seen_artists = {d["artist"]["name"].lower() for d in drops}
seen_all_artists = {s["a"].lower() for d in drops for s in d["songs"]}
today = datetime.date.today()

PROMPT = f"""Today is {today:%A, %B %d, %Y}. Build this week's music drop for one listener.

Taste: loves {', '.join(taste['loves'])}. Genres: {taste['genres']}.
AVOID: {taste['avoid']}. Never include these blocked artists: {', '.join(taste['blocklist']) or 'none'}.

Use web search to find real, currently available music. Requirements:
- 10 songs total: about 7 released in the last ~3 weeks and about 3 older gems (any year).
- ONE "artist of the week": a smaller/rising artist the listener has likely never heard, whose lane matches the taste. Their song is song #1. Never pick any of these previous artists: {', '.join(sorted(seen_artists)) or 'none'}.
- Do not repeat any of these artists/songs from earlier drops: {', '.join(sorted(seen_all_artists)) or 'none'}.
- NO AI-generated artists. Before choosing the artist of the week, confirm with search that they are real people/band (named members, label or booking, live shows or press). Describe that evidence in "check". If you cannot confirm, pick someone else.
- Only include songs you confirmed exist via search. Do not invent titles.

Reply with ONLY JSON, no markdown fences, in exactly this shape:
{{"week":"{today:%b %d, %Y}","artist":{{"name":"","blurb":"2-3 sentences","check":"Real-artist check: ...","url":""}},
"songs":[{{"a":"artist","t":"title","y":"year","n":1,"w":"one sentence on why it fits"}}]}}
"n" is 1 for new releases, 0 for older gems. Leave artist "url" empty unless you have a real open.spotify.com artist link."""

def call(messages):
    body = {"model": MODEL, "max_tokens": 8000, "messages": messages,
            "tools": [{"type": "web_search_20250305", "name": "web_search", "max_uses": 12}]}
    req = urllib.request.Request("https://api.anthropic.com/v1/messages",
        data=json.dumps(body).encode(), method="POST",
        headers={"content-type": "application/json", "anthropic-version": "2023-06-01",
                 "x-api-key": os.environ["ANTHROPIC_API_KEY"]})
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            return json.load(r)
    except urllib.error.HTTPError as e:
        sys.exit(f"API error {e.code}: {e.read().decode()[:500]}")

def run():
    msgs = [{"role": "user", "content": PROMPT}]
    for _ in range(6):  # handle long-running search turns
        resp = call(msgs)
        if resp.get("stop_reason") != "pause_turn":
            break
        msgs.append({"role": "assistant", "content": resp["content"]})
    text = "".join(b.get("text", "") for b in resp["content"] if b["type"] == "text")
    m = re.search(r"\{.*\}", text, re.S)
    if not m: raise ValueError("no JSON in reply")
    return json.loads(m.group(0))

def valid(d):
    s = d.get("songs", [])
    if len(s) < 8 or not d.get("artist", {}).get("name"): return False
    if d["artist"]["name"].lower() in seen_artists | {x.lower() for x in taste["blocklist"]}: return False
    if any((x["a"].lower(), x["t"].lower()) in seen_songs for x in s): return False
    return all({"a", "t", "y", "w"} <= set(x) for x in s)

for attempt in range(3):
    try:
        d = run()
        if valid(d): break
        print("Drop failed validation, retrying", file=sys.stderr)
    except Exception as e:
        print("Attempt failed:", e, file=sys.stderr)
else:
    sys.exit("Could not produce a valid drop")

drops.insert(0, d)
json.dump(drops, open(path, "w"), indent=1, ensure_ascii=False)
print("Added drop:", d["week"], "-", d["artist"]["name"])
